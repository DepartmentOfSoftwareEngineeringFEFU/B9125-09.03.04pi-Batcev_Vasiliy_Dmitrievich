#include <iostream>
#include "oper_vector.h"
using namespace std;

double scalarnoe(Vector v1, Vector v2) {
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
};

Vector vectornoe(Vector v1, Vector v2) {
    Vector v3;
    v3.x = v1.y * v2.z - v1.z * v2.y;
    v3.y = v1.z * v2.x - v1.x * v2.z;
    v3.z = v1.x * v2.y - v1.y * v2.x;
    return v3;
};

double smechanoe(Vector v1, Vector v2, Vector v3) {
    return scalarnoe(vectornoe(v1, v2), v3);
};

bool kollienar(Vector v1, Vector v2) {
    Vector v3 = vectornoe(v1, v2);
    if (v3.x == 0 and v3.y == 0 and v3.z == 0 ) {
        return true;
    } else {
        return false;
    }
};

bool komplanarnost(Vector v1, Vector v2, Vector v3) {
    if (smechanoe(v1, v2, v3) == 0) {
        return true;
    } else {
        return false;
    }
};