#include <iostream>
#include "oper_vector.h"
using namespace std;

int main() {
    system("chcp 65001 > nul");
    cout << endl << endl;
    cout << "Тестирование модуля - операции над векторами, черным ящиком." << endl;
    cout << endl;
    Vector a{1, 2, 3};
    Vector b{2, 4, 6};
    Vector c{1, 2, 3};
    Vector d{1, 0, 0};
    Vector e{1, 0, 0};
    Vector f{0, 1, 0};
    Vector g{1, 1, 0};
    Vector h{0, 0, 1};
    Vector i{4, 5, 6};
    Vector j{1, 1, 1};
    Vector zero{0, 0, 0};
    Vector ortho{0, 5, 0};

    cout << "-----------------------------------" << endl;
    cout << "Метод эквивалентных разбиений:" << endl;
    cout << "-----------------------------------" << endl;
    cout << endl;

    cout << "Скалярное произведение" << endl;
    cout << "Ожидание: 32" << endl;
    cout << "Реальность: " << scalarnoe(a, i) << endl;
    cout << endl;

    cout << "Векторное произведение" << endl;
    Vector s = vectornoe(a, i);
    cout << "Ожидание: (-3, 6, -3)" << endl;
    cout << "Реальность: (" << s.x << ", " << s.y << ", " << s.z << ")" << endl;
    cout << endl;

    cout << "Смешанное произведение" << endl;
    cout << "Ожидание: 1" << endl;
    cout << "Реальность: " << smechanoe(e, f, j) << endl;
    cout << endl;

    cout << "Коллинеарные векторы" << endl;
    cout << "Ожидание: векторы коллинеарны" << endl;
    cout << "Реальность: ";
    if (kollienar(a, b)) {
        cout << "векторы коллинеарны";
    } else {
        cout << "векторы НЕ коллинеарны";
    }
    cout << endl << endl;

    cout << "Неколлинеарные векторы" << endl;
    cout << "Ожидание: векторы НЕ коллинеарны" << endl;
    cout << "Реальность: ";
    if (kollienar(c, d)) {
        cout << "векторы коллинеарны";
    } else {
        cout << "векторы НЕ коллинеарны";
    }
    cout << endl << endl;

    cout << "Компланарные векторы" << endl;
    cout << "Ожидание: векторы компланарны" << endl;
    cout << "Реальность: ";
    if (komplanarnost(e, f, g)) {
        cout << "векторы компланарны";
    } else {
        cout << "векторы НЕ компланарны";
    }
    cout << endl << endl;

    cout << "Некомпланарные векторы" << endl;
    cout << "Ожидание: векторы НЕ компланарны" << endl;
    cout << "Реальность: ";
    if (komplanarnost(e, f, h)) {
        cout << "векторы компланарны";
    } else {
        cout << "векторы НЕ компланарны";
    }
    cout << endl << endl;

    cout << "-----------------------------------" << endl;
    cout << "Метод граничных значений:" << endl;
    cout << "-----------------------------------" << endl;
    cout << endl;

    cout << "Скалярное произведение с нулевым вектором" << endl;
    cout << "Ожидание: 0" << endl;
    cout << "Реальность: " << scalarnoe(a, zero) << endl;
    cout << endl;

    cout << "Векторное произведение с нулевым вектором" << endl;
    Vector s_zero = vectornoe(a, zero);
    cout << "Ожидание: (0, 0, 0)" << endl;
    cout << "Реальность: (" << s_zero.x << ", " << s_zero.y << ", " << s_zero.z << ")" << endl;
    cout << endl;

    cout << "Скалярное произведение ортогональных векторов" << endl;
    cout << "Ожидание: 0" << endl;
    cout << "Реальность: " << scalarnoe(d, ortho) << endl;
    cout << endl;

    cout << "Коллинеарность с нулевым вектором" << endl;
    cout << "Ожидание: векторы коллинеарны" << endl;
    cout << "Реальность: ";
    if (kollienar(a, zero)) {
        cout << "векторы коллинеарны";
    } else {
        cout << "векторы НЕ коллинеарны";
    }
    cout << endl << endl;

    cout << "Компланарность с нулевым вектором" << endl;
    cout << "Ожидание: векторы компланарны" << endl;
    cout << "Реальность: ";
    if (komplanarnost(e, f, zero)) {
        cout << "векторы компланарны";
    } else {
        cout << "векторы НЕ компланарны";
    }
    cout << endl << endl;

    return 0;
}
