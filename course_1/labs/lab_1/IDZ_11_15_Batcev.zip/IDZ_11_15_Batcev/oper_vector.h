#ifndef _OPER_VECTOR_H
#define _OPER_VECTOR_H

struct Vector {
    double x;
    double y;
    double z;
};

double scalarnoe(Vector v1, Vector v2);
Vector vectornoe(Vector v1, Vector v2);
double smechanoe(Vector v1, Vector v2, Vector v3);
bool kollienar(Vector v1, Vector v2);
bool komplanarnost(Vector v1, Vector v2, Vector v3);

#endif